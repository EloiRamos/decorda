# DECORDA TV UI — Final Design v1.0
## Concept A · "The Record"

Final design deliverable for the DECORDA shared-decision television UI.
This package contains Concept A only, exactly as designed in Phase 1.
No presentation layer, no alternative concepts, no recommendation material.

---

## Run it

Open `index.html` in any modern browser. Double-click is enough.

The page presents the **STATE navigator** and its instruction line above the
framed Concept A product UI. The navigator jumps directly to any of the six
states; the frame itself is the product.

- No build step.
- No package install.
- No CDN, no fonts to download, no network access of any kind.
- No runtime dependency on the Phase-1 authoring environment.

Three files carry the product: `index.html`, `styles.css`, `app.js`.

---

## What this is

A shared decision, shown on a television, for a room of four people
using only a D-pad, OK and Back.

Concept A's structural argument: a **permanent truth spine** on the left
that never disappears, and a right side that shows **exactly one stage**
of the decision at a time. The record is always readable; the work is
always singular.

Reference canvas is 1920x1080, authored for roughly 3 m viewing distance.
The canvas is uniformly scaled to fit the display and never reflowed —
type sizes, focus rings and safe margins hold their designed proportions
at every screen size.

---

## Screens

| # | Screen | What it establishes |
|---|--------|---------------------|
| 1 | Open | Nothing exists until asked for. Not-found state and the six truthful outcome families. |
| 2 | Constraints + Candidates | Hard constraints gate feasibility; two of four options clear them. |
| 3 | Decision Details | Bounded child view. Evidence is read without the record leaving the screen. |
| 4 | Individual Responses | Four responses, consensus reached, ready to confirm. |
| 5 | Plan Confirmed | Canonical state, with decision/CAS version and plan version shown as two distinct numbers. |
| 6 | Context Change + Scoped Reapproval | Affected-only replanning; the preserved part stays saved. |

---

## Controls

| Input | Remote equivalent | Behavior |
|-------|-------------------|----------|
| Arrow keys | D-pad | Move focus between controls on the current screen |
| Enter | OK | Activate the focused control |
| Backspace | Back | Return along the stage path — never writes |
| Mouse click | (authoring convenience) | Mirrors OK on the same controls |
| STATE buttons | (review convenience) | Jump straight to any of the six states |

The keyboard is a local proxy for the remote, not a product input.
Focus order follows the authored `data-f` sequence on each screen.

---

## Frozen product rules honored by this design

1. Four approvals mean **ready**. Only explicit Confirm commits a plan.
2. Decision/CAS version and plan version remain two distinct concepts.
3. Affected-only replanning, scoped renewed approval, zero-write Back.
4. Polling refresh; stale, conflict, limit and expiry stay visible and truthful.

---

## Scope

This is a **design deliverable**: presentation, information architecture
and visual specification. Screens carry synthetic fixture content
("Saturday Plan · Synthetic Fixture") and there is no backend, no
persistence and no real decision service. Navigation between screens is
the only behavior implemented — it exists so the design can be walked,
not to simulate the product's write path.

See `HANDOFF.md` for implementation notes.
