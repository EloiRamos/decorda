# HANDOFF — DECORDA TV UI, Concept A "The Record" v1.0

For the engineer implementing this design against the real decision service.

---

## 1. Package contents

| File | Role |
|------|------|
| `index.html` | STATE navigator + instruction line, then all six screens |
| `styles.css` | Document reset, canvas fit frame, D-pad focus treatments |
| `app.js` | State navigator, screen state, focus model, Back path, canvas fit |
| `README.md` | How to open it, what it is, controls |
| `HANDOFF.md` | This file |

Standalone by construction: no imports, no fetches, no fonts, no build.

---

## 2. Canvas and scaling

- Design canvas: **1920 x 1080**, fixed. Every dimension in the markup is
  authored against it.
- `#stage` is exactly 1920x1080 and is transformed by `app.js`:
  `scale(frameWidth / 1920)` inside a 16:9 `#frame`.
- **Do not reflow this design.** It is a television layout, not a responsive
  page. Uniform scale is the intended and only adaptation.
- Minimum type size on the canvas is 19px at 1920 width. Keep that floor:
  below it, the 3 m reading distance fails.

The STATE navigator and instruction line are **review scaffolding**, not
product UI: they let a reviewer reach any state directly with a pointer.
Everything inside `#frame` is the product. Drop the navigator when
implementing; keep the frame's contents verbatim.

## 3. Visual system

| Token | Value | Use |
|-------|-------|-----|
| Ground | `#0E1116` | Screen background |
| Panel | `#151A21` | Cards, evidence blocks |
| Recessed panel | `#11151B` | Unavailable / not-feasible rows |
| Rule | `#2A323D` | Spine divider, card borders |
| Ink | `#EDF0F3` | Primary text |
| Ink secondary | `#C9D4DE` | Supporting text |
| Ink tertiary | `#9FAEBD` | Monospace labels, metadata |
| Signal | `#E8B44A` | Stage label, primary action, attention marks, focus ring |
| Absolute | `#F2F5F8` | Consensus and confirmation marks |
| Action ink on signal | `#10131A` | Text on the amber primary button |

Type: `'Helvetica Neue', Helvetica, Arial, sans-serif` for voice;
`ui-monospace, Menlo, Consolas, monospace` for machine truth — labels,
versions, status marks, states. **That split is load-bearing.** Monospace
means "this is what the system says", proportional means "this is what the
decision says". Do not merge them.

Marks, used consistently across all screens:
`◷` working · `▲` attention (stale / conflict / invalidated) ·
`■` terminal (unavailable / expired) · `◌` limit or nothing-yet ·
`✓` approved / feasible · `✕` not feasible · `◆` affected · `▣` preserved.

No gradients, no shadows for depth, no rounded corners, no iconography
beyond these marks. Borders and weight carry hierarchy.

## 4. Structure

Every screen is `grid-template-columns: 544px 1fr` with a 56px gap and
52px/64px padding.

- **Left (544px): the spine.** Wordmark, fixture identity, then stacked
  hairline-separated blocks: session mode, canonical state, decision version,
  plan version, participants, constraint wall, live status. The spine is
  *never* replaced — including inside the Details child view, where it
  explains the boundedness instead.
- **Right (1fr): exactly one stage.** Monospace stage label, one headline
  sentence, then the stage's own content. One stage on screen at a time.

## 5. Focus model

- Focusable controls carry `tabindex="0"` and `data-f="<n>"`.
- `app.js` collects visible `[data-f]` in DOM order and moves linearly:
  Right/Down advance, Left/Up retreat, clamped at both ends. No wrap.
- `data-f` numbers are the authored intent. When you add or remove controls,
  renumber so DOM order and reading order agree.
- Focus treatment: 5px amber outline at 6px offset, ~1.02–1.04 scale, plus an
  inset ring in the control's own contrast color. The classes `fx1`–`fx6` in
  `styles.css` hold the six authored variants; they use `!important` because
  controls declare `outline:none` inline.
- Focus must be visible from 3 m. Do not soften the ring.

## 6. Navigation and the Back contract

`app.js` holds the screen map:

    details   -> decide
    respond   -> decide
    replan    -> confirmed
    confirmed -> respond
    decide    -> open

**Back never writes.** No commit, no approval, no draft merge, no retry.
On screen 6, Back abandons the scoped draft with zero durable mutation.
Preserve this exactly — it is a frozen rule, not a convenience.

Details is a **bounded child view**, not a navigation level. Back from it
returns to the originating candidate's own Inspect control. The prototype
returns to the candidate list; wiring Back to the exact originating control
is an implementation task.

## 7. Wiring to the real service

Replace the prototype's screen switching with real state. The design assumes:

1. **Open never creates.** Opening reads canonical state or reports not-found.
   The fixture must be started explicitly.
2. **Two version numbers, always distinct.** Decision/CAS version advances on
   every canonical write *attempt*; plan version advances only when a plan is
   confirmed. Screen 5 shows them as separate, differently-labeled figures.
   Never collapse them into one "version".
3. **Confirm is the only commit.** Activating Confirm enters a saving state
   that blocks duplicate activation. Nothing is persisted until canonical
   success returns. Four approvals produce *ready*, never *committed*.
4. **Feasibility is computed and explained.** Every not-feasible row states
   which hard constraint it violates, in the row itself. Never show a
   disabled option without its reason.
5. **Soft preferences are trade-offs, not gates.** Museum Workshop is
   feasible and says so while also saying it misses the outdoor preference.
6. **Replanning is affected-only.** The affected component is marked
   `◆ AFFECTED · MAY CHANGE`; everything else is `▣ PRESERVED · STAYS AS SAVED`
   and is not reopened. Renewed approval is scoped to the affected part, and
   Confirm stays UNAVAILABLE until four renewed responses arrive.
7. **Polling refresh, truthful states.** Refresh every 2000 ms while a screen
   is active. Unchanged state must cause **no visual reset** — no flicker, no
   focus loss, no scroll jump. Stale, conflict, unavailable, expired and read
   limit each keep their own visible, distinct wording. Never silently retry,
   never fall back to local state, never hide an expiry.
8. **Draft invalidation is announced.** If a newer canonical version
   invalidates an unfinished scoped draft, say so and state that nothing was
   merged.

The six outcome families on screen 1 are the complete vocabulary. Any new
failure must be expressed as one of them, with the same mark and the same
plainness — or the vocabulary gets extended deliberately, not incidentally.

## 8. Content rules

- Fixture content is synthetic and labeled as such
  ("SATURDAY PLAN · SYNTHETIC FIXTURE", "Deterministic synthetic fixture
  condition, not live weather"). If real data ships, that labeling must go —
  and only then.
- Copy is declarative and past-tense about effects: "Nothing was retried",
  "No action was saved", "Nothing was merged". Keep that register.
- No exclamation, no apology, no encouragement, no emoji.

## 9. Accessibility

- Contrast: primary ink on ground is ~14:1; tertiary labels ~6:1. The lowest
  pairing in the design is above 4.5:1. Hold that floor.
- Interactive elements are currently `div[tabindex=0]`. In production use
  `<button>` elements (or add `role="button"` and Space/Enter handling) so
  screen readers and TV accessibility services announce them correctly.
- Add `aria-live="polite"` to the LIVE STATUS block in the spine so status
  transitions are announced without stealing focus.
- Screens are siblings toggled by `display`; hidden screens are correctly
  removed from the accessibility tree.
