/* DECORDA TV UI — Concept A "The Record" — v1.0 final
   Standalone runtime: state navigator, screen state, D-pad focus model,
   zero-write Back, canvas fit. No dependencies. No network. */
(function () {
  "use strict";

  var CANVAS_W = 1920, CANVAS_H = 1080;

  var frame = document.getElementById("frame");
  var stage = document.getElementById("stage");
  var screens = {};
  var order = ["open", "decide", "details", "respond", "confirmed", "replan"];
  var buttons = Array.prototype.slice.call(document.querySelectorAll(".statebtn"));

  Array.prototype.forEach.call(stage.querySelectorAll("[data-screen]"), function (el) {
    screens[el.getAttribute("data-screen")] = el;
  });

  var current = "open";

  /* Back is navigation only: it never writes, never commits, never approves. */
  var BACK = {
    details: "decide",
    respond: "decide",
    replan: "confirmed",
    confirmed: "respond",
    decide: "open"
  };

  function show(name) {
    if (!screens[name]) return;
    order.forEach(function (n) {
      if (screens[n]) screens[n].style.display = n === name ? "grid" : "none";
    });
    buttons.forEach(function (b) {
      b.setAttribute("aria-current", b.getAttribute("data-state") === name ? "true" : "false");
    });
    current = name;
  }

  function back() {
    var to = BACK[current];
    if (to) show(to);
  }

  /* Uniform fit of the 1920x1080 canvas to the frame width. */
  function fit() {
    stage.style.transform = "scale(" + (frame.clientWidth / CANVAS_W) + ")";
  }

  buttons.forEach(function (b) {
    b.addEventListener("click", function () { show(b.getAttribute("data-state")); });
  });

  /* Pointer activation mirrors OK on the same controls. */
  stage.addEventListener("click", function (e) {
    var t = e.target;
    while (t && t !== stage && !t.getAttribute("data-go")) t = t.parentNode;
    if (t && t !== stage) show(t.getAttribute("data-go"));
  });

  /* D-pad / OK / Back. Keyboard is a local proxy for the remote. */
  document.addEventListener("keydown", function (e) {
    var k = e.key;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Enter", "Backspace"].indexOf(k) < 0) return;

    if (k === "Backspace") { e.preventDefault(); back(); return; }

    var items = Array.prototype.slice.call(stage.querySelectorAll("[data-f]"))
      .filter(function (el) { return el.offsetParent !== null; });
    if (!items.length) return;

    var cur = items.indexOf(document.activeElement);

    if (k === "Enter") {
      if (cur >= 0) { e.preventDefault(); items[cur].click(); }
      return;
    }

    e.preventDefault();
    var next;
    if (cur < 0) next = 0;
    else if (k === "ArrowRight" || k === "ArrowDown") next = Math.min(items.length - 1, cur + 1);
    else next = Math.max(0, cur - 1);
    items[next].focus({ preventScroll: true });
  });

  window.addEventListener("resize", fit);
  fit();
  show("open");
})();
